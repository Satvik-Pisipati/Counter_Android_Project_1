package ch.zli.counter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Integer counter = 0;
    Button plusOne;
    Button minusOne;
    Button reset;
    TextView counterDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        plusOne = (Button) findViewById(R.id.plusOne);
        minusOne = (Button) findViewById(R.id.minusOne);
        reset = (Button) findViewById(R.id.reset);
        counterDisplay = (TextView) findViewById(R.id.counter);

        plusOne.setOnClickListener(v -> {
            counter++;
            counterDisplay.setText(counter.toString());
        });

        minusOne.setOnClickListener(v -> {
            counter--;
            counterDisplay.setText(counter.toString());
        });

        reset.setOnClickListener(v -> {
            counter = 0;
            counterDisplay.setText(counter.toString());
        });


    }


}